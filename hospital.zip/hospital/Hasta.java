public class Hasta { // Hasta sınıfı başlangıcı

    // Hasta bilgilerini tutacak özellikler tanımlanıyor.
    private String isim; // Hasta ismini tutan özellik
    private String soyisim; // Hasta soyismini tutan özellik
    private int hastaID; // Hasta kimlik numarasını tutan özellik
    private Durum hastaDurumu; // Hasta durumunu (Durum sınıfından nesne) tutan özellik

    // Parametresiz kurucu metot
    public Hasta() {
    }

    // Parametre alan kurucu metot
    public Hasta(String isim, String soyisim, int hastaID, Durum hastaDurumu) {
        // Parametreler kullanılarak Hasta özellikleri atanıyor.
        this.isim = isim;
        this.soyisim = soyisim;
        this.hastaID = hastaID;
        this.hastaDurumu = hastaDurumu;
    }

    // İsim özelliğinin getter metodu
    public String getIsim() {
        return isim;
    }

    // İsim özelliğinin setter metodu
    public void setIsim(String isim) {
        this.isim = isim;
    }

    // Soyisim özelliğinin getter metodu
    public String getSoyisim() {
        return soyisim;
    }

    // Soyisim özelliğinin setter metodu
    public void setSoyisim(String soyisim) {
        this.soyisim = soyisim;
    }

    // Hasta ID özelliğinin getter metodu
    public int getHastaID() {
        return hastaID;
    }

    // Hasta ID özelliğinin setter metodu
    public void setHastaID(int hastaID) {
        this.hastaID = hastaID;
    }

    // Hasta durumu özelliğinin getter metodu
    public Durum getHastaDurumu() {
        return hastaDurumu;
    }

    // Hasta durumu özelliğinin setter metodu
    public void setHastaDurumu(Durum hastaDurumu) {
        this.hastaDurumu = hastaDurumu;
    }

    // Hasta nesnesinin string temsilini oluşturan metot
    @Override
    public String toString() {
        return "Hasta{" +
                "isim='" + isim + '\'' +
                ", soyisim='" + soyisim + '\'' +
                ", hastaID=" + hastaID +
                ", hastaDurumu=" + hastaDurumu +
                '}';
    }

}
