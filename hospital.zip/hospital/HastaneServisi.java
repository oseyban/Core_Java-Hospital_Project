import java.io.IOException;
import java.util.LinkedList;
import java.util.Scanner;

import static hospital.DoktorServisi.*;
import static hospital.Islemler.hastaBul;
import static hospital.Islemler.hastaDurumuBul;

public class HastaneServisi { // HastaneServisi sınıfı başlangıcı
    
    // Scanner nesnesi oluşturuluyor
    static Scanner scan = new Scanner(System.in);
    
    // Doktor ve Hasta nesneleri oluşturuluyor
    static Doktor doktor = new Doktor();
    static Hasta hasta = new Hasta();
    
    // Hasta ve Hasta Durum Listeleri oluşturuluyor
    static LinkedList<Hasta> hastaListesi = new LinkedList<>();
    static LinkedList<Durum> hastaDurumListesi = new LinkedList<>();
    
    // Hastane nesnesi oluşturuluyor
    private static Hastane hastane2 = new Hastane();

    // Hasta ekleme işlemini gerçekleştiren metod
    public static void hastaEkle() {
        // Metodun içeriği buraya yazılacak
    }

    // Uygulamayı başlatan metod
    public static void start() throws InterruptedException, IOException {
        // Metodun içeriği buraya yazılacak
    }

    // Hastane servisi menüsünü gösteren metod
    private static void hastaneServisiMenu() throws IOException, InterruptedException {
        // Metodun içeriği buraya yazılacak
    }

    // Doktor ekleme işlemini gerçekleştiren metod
    public static void doktorEkle() {
        // Metodun içeriği buraya yazılacak
    }

    // Hasta silme işlemini gerçekleştiren metod
    public static void hastaSil() {
        // Metodun içeriği buraya yazılacak
    }

    // Hasta listesini gösteren metod
    public static void hastaListele() {
        // Metodun içeriği buraya yazılacak
    }

    // Metni yavaşça yazdıran metod
    public static void slowPrint(String text, int delay) {
        // Metodun içeriği buraya yazılacak
    }

}
