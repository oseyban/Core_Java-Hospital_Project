public class Hastane extends VeriBankasi { // Hastane sınıfı başlangıcı

    // Hastanenin içinde bir doktor ve bir hasta nesnesi bulunuyor.
    Doktor doktor = new Doktor(); // Bir doktor nesnesi oluşturuluyor
    Hasta hasta = new Hasta(); // Bir hasta nesnesi oluşturuluyor

    // Parametresiz kurucu metot
    public Hastane() {
    }

    // Parametre alan kurucu metot
    public Hastane(Doktor doktor, Hasta hasta) {
        // Parametreler kullanılarak Hastane özellikleri atanıyor.
        this.doktor = doktor;
        this.hasta = hasta;
    }

    // Doktor nesnesinin getter metodu
    public Doktor getDoktor() {
        return doktor;
    }

    // Doktor nesnesinin setter metodu
    public void setDoktor(Doktor doktor) {
        this.doktor = doktor;
    }

    // Hasta nesnesinin getter metodu
    public Hasta getHasta() {
        return hasta;
    }

    // Hasta nesnesinin setter metodu
    public void setHasta(Hasta hasta) {
        this.hasta = hasta;
    }
}
