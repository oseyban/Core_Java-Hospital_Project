public class Durum { // Durum sınıfı başlangıcı

    // Hasta durumunu (aktüel durum) ve aciliyetini tutan özellikler tanımlanıyor.
    private String aktuelDurum; // Hasta durumunu temsil eden özellik
    private boolean aciliyet; // Hasta durumunun aciliyetini temsil eden özellik

    // Parametresiz kurucu metot
    public Durum() {
    }

    // Parametre alan kurucu metot
    public Durum(String aktuelDurum, boolean aciliyet) {
        // Parametreler kullanılarak Durum özellikleri atanıyor.
        this.aktuelDurum = aktuelDurum;
        this.aciliyet = aciliyet;
    }

    // Hasta durumu özelliğinin getter metodu
    public String getAktuelDurum() {
        return aktuelDurum;
    }

    // Hasta durumu özelliğinin setter metodu
    public void setAktuelDurum(String aktuelDurum) {
        this.aktuelDurum = aktuelDurum;
    }

    // Aciliyet özelliğinin getter metodu
    public boolean isAciliyet() {
        return aciliyet;
    }

    // Aciliyet özelliğinin setter metodu
    public void setAciliyet(boolean aciliyet) {
        this.aciliyet = aciliyet;
    }

    // Durum nesnesinin string temsilini oluşturan metot
    @Override
    public String toString() {
        return "Durum{" +
                "Hasta Durumu:'" + aktuelDurum + '\'' +
                ", aciliyet=" + aciliyet +
                '}';
    }
}
