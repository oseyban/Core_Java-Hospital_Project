public class HastaneRunner { // HastaneRunner sınıfı başlangıcı

    public static void main(String[] args) throws InterruptedException, IOException {
        // Uygulama başlatılıyor
        start(); // Hastane servisi başlatılıyor
    }
}
