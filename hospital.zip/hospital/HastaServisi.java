import java.io.IOException;

import static hospital.HastaneServisi.*;
import static hospital.Islemler.*;

public class HastaServisi { // HastaServisi sınıfı başlangıcı

    // Hasta giriş menüsünü gösteren metod
    public static void hastaGirisiMenu() throws InterruptedException, IOException {
        int secim = -1;
        do {
            // Kullanıcıya seçeneklerin listelendiği bir menü gösteriliyor
            System.out.println("=========================================");
            System.out.println("LUTFEN YAPMAK ISTEDIGINIZ ISLEMI SECINIZ:\n\t=> 1-HASTA EKLE\n\t=> 2-HASTALARI LISTELE\n\t" +
                    "=> 3-HASTA BUL\n\t=> 4-HASTA SIL\n\t=> 5-HASTA DURUMU LISTELE\n\t=> 6-ANA MENU");
            System.out.println("=========================================");
            try {
                // Kullanıcının seçimini alıyoruz
                secim = scan.nextInt();
                scan.nextLine(); // Dummy
            } catch (Exception e) {
                // Hata durumunda kullanıcıya uyarı veriliyor ve döngü devam ettiriliyor
                scan.nextLine(); // Dummy
                System.out.println("\"LUTFEN SIZE SUNULAN SECENEKLERIN DISINDA VERI GIRISI YAPMAYINIZ!\"");
                continue;
            }
            // Kullanıcının seçimine göre işlemler yapılıyor
            switch (secim) {
                case 1:
                    hastaEkle(); // Hasta ekleme işlemi
                    break;
                case 2:
                    hastalariListele(); // Hastaları listeleme işlemi
                    Thread.sleep(3000); // 3 saniye bekletme
                    break;
                case 3:
                    // Kullanıcıdan bir hastanın durumunu alıp bulma işlemi yapılıyor
                    System.out.println("BULMAK İSTEDİĞİNİZ HASTANIN DURUMUNU GİRİNİZ...");
                    String durum = scan.next();
                    hastaBul(durum); // Hasta bulma işlemi
                    break;
                case 4:
                    hastaSil(); // Hasta silme işlemi
                    break;
                case 5:
                    // Hasta durumlarını listeleme işlemi
                    // Bu kısım henüz implemente edilmemiş
                    break;
                case 0:
                    // Ana menüye dönme işlemi
                    slowPrint("ANA MENUYE YÖNLENDİRİLİYORSUNUZ...\n", 20);
                    HastaneServisi.start(); // Hastane servisi başlatma işlemi
                    break;
                default:
                    // Geçersiz seçenek durumunda kullanıcıya uyarı veriliyor
                    System.out.println("HATALI GİRİŞ, TEKRAR DENEYİNİZ...\n");
            }
        } while (secim != 0); // Kullanıcı 0 (ana menü) seçeneğini girene kadar döngü devam ediyor
    }

    // İlk liste oluşturma işlemini gerçekleştiren metod
    public static void firstList() {
        // VeriBankasi sınıfındaki durumlar listesindeki her bir durum için bir hasta ve hasta durumu oluşturulup listelere ekleniyor
        for (String w : VeriBankasi.durumlar) {
            hastaListesi.add(hastaBul(w)); // Hasta bulma işlemi ve listeye ekleme
            hastaDurumListesi.add(hastaDurumuBul(w.toLowerCase())); // Hasta durumu bulma işlemi ve listeye ekleme
        }
    }
}
