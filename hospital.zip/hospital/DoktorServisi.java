package hospital; // hospital paketi altında bu sınıf yer alıyor.

import java.io.IOException;
import java.util.LinkedList;
import java.util.Scanner;

import static hospital.HastaneServisi.scan;
import static hospital.HastaneServisi.slowPrint;
import static hospital.HastaneServisi.start;
import static hospital.Islemler.hastaBul;

public class DoktorServisi { // DoktorServisi sınıfı başlangıcı

    // Hastane içerisinde bulunan doktorları tutacak bir linked list tanımlanıyor.
    static LinkedList<Doktor> doktorList = new LinkedList<>();

    // Doktor girişi için kullanıcı arayüzünü oluşturan metod.
    public static void doktorGirisiMenu() throws InterruptedException, IOException {
        // Kullanıcının seçim yapabileceği bir döngü başlatılıyor.
        int secim = -1;
        do {
            // Kullanıcıya seçenekler gösteriliyor.
            System.out.println("=========================================");
            System.out.println("LUTFEN YAPMAK ISTEDIGINIZ ISLEMI SECINIZ:\n\t=> 1-DOKTORLARI LISTELE\n\t" +
                    "=> 2-UNVANDAN DOKTOR BULMA\n\t=> 3-HASTA BULMA\n\t=> 4-HASTALARI LISTELE \n\t=>0-ANAMENU");
            System.out.println("=========================================");
            try {
                secim = scan.nextInt(); // Kullanıcının seçimini oku
            } catch (Exception e) {
                scan.nextLine();//dummy
                System.out.println("\"LUTFEN SIZE SUNULAN SECENEKLERIN DISINDA VERI GIRISI YAPMAYINIZ!\"");
                continue;
            }
            // Kullanıcının seçimine göre ilgili işlemi yapacak kod blokları
            switch (secim) {
                case 1:
                    doktorlariListele(); // Doktorları listeleme işlemi
                    break;
                case 2:
                    unvandanDoktorBul(); // Unvanına göre doktor bulma işlemi
                    break;
                case 3:
                    // Hasta bulma işlemi
                    System.out.println("BULMAK İSTEDİĞİNİZ HASTANIN DURUMUNU GİRİNİZ...");
                    String durum = scan.next();
                    hastaBul(durum);
                    break;
                case 4:
                    // Hastaları listeleme işlemi
                    //
                    break;
                case 0:
                    slowPrint("ANA MENUYE YÖNLENDİRİLİYORSUNUZ...\n", 20); // Ana menüye geri dönme işlemi
                    start();
                    break;
                default:
                    System.out.println("HATALI GİRİŞ, TEKRAR DENEYİNİZ...\n");
            }
        } while (secim != 0); // Kullanıcı 0'a basana kadar döngü devam edecek
    }

    // Doktor listesini ekrana yazdıran metod.
    public static void doktorlariListele () {
        System.out.println("------------------------------------------------------");
        System.out.println("---------- HASTANEDE BULUNAN DOKTORLARİMİZ -----------");
        System.out.printf("%-13s | %-15s | %-15s\n", "DOKTOR İSİM", "DOKTOR SOYİSİM", "DOKTOR UNVAN");
        System.out.println("------------------------------------------------------");
        for (Doktor w : doktorList) {
            System.out.printf("%-13s | %-15s | %-15s\n", w.getIsim(), w.getSoyisim(), w.getUnvan());
        }
    }

    // Doktor silme işlemini gerçekleştiren metod.
    public static void doktoruSil() {
        doktorlariListele(); // Önce doktorları listele
        Scanner scan = new Scanner(System.in);
        System.out.println("Silmek istediginiz doktor ismini giriniz");
        String doktorName = scan.next();
        System.out.println("Silmek istediginiz doktor soyadini giriniz");
        String doktorSurname = scan.next();

        boolean isDeleted = false;
        // Listede dönerek silinecek doktoru bul ve listeden çıkar
        for (Doktor w : doktorList) {
            if (w.getIsim().equalsIgnoreCase(doktorName) && w.getSoyisim().equalsIgnoreCase(doktorSurname)) {
                doktorList.remove(w);
                isDeleted = true;
                break;
            }
        }
        // Eğer silinen bir doktor yoksa bilgilendirme yap
        if (!isDeleted) {
            System.out.println("SİLMEK İSTEDİGİNİZ DOKTOR LİSTEMİZDE BULUNMAMAKTADIR");
        }
        doktorlariListele(); // Güncellenmiş doktor listesini tekrar listele
    }

    // Unvanına göre doktor arama işlemini gerçekleştiren metod.
    public static void unvandanDoktorBul() {
        System.out.println("Bulmak Istediginiz Doktorun Unvanini Giriniz:\n\t=> Allergist\n\t=> Norolog\n\t" +
                "=> Genel Cerrah\n\t=> Cocuk Doktoru\n\t=> Dahiliye Uzmanı\n\t=> Kardiolog");
        scan.nextLine();
        String unvan = scan.nextLine();

        System.out.println("------------------------------------------------------");
        System.out.println("---------- HASTANEDE BULUNAN DOKTORLARİMİZ -----------");
        System.out.printf("%-13s | %-15s | %-15s\n", "DOKTOR İSİM", "DOKTOR SOYİSİM", "DOKTOR UNVAN");
        System.out.println("------------------------------------------------------");
        boolean varMi = false;

        // Unvana göre doktorları listele
        for (Doktor w : doktorList) {
            if (w.getUnvan().equalsIgnoreCase(unvan)) {
                System.out.printf("%-13s | %-15s | %-15s\n", w.getIsim(), w.getSoyisim(), w.getUnvan());
                varMi = true;
            }
        }
        // Eğer aranan unvandaki doktor yoksa bilgilendirme yap
        if (!varMi) {
            System.out.println("BU UNVANA AİT DOKTOR BULUNMAKTADIR");
slowPrint("\033[39mANAMENU'YE YONLENDIRILIYORSUNUZ...\033[0m\n", 20);
}
System.out.println("------------------------------------------------------");
}
// Veri tabanından bir doktorun bilgilerini getiren metod.
public static Doktor doktorBul(String unvan){
    Doktor doktor = new Doktor();
    for (int i = 0; i < VeriBankasi.unvanlar.size(); i++) {
        if (VeriBankasi.unvanlar.get(i).equals(unvan)) {
            doktor.setIsim(VeriBankasi.doctorIsimleri.get(i));
            doktor.setSoyisim(VeriBankasi.doctorSoyIsimleri.get(i));
            doktor.setUnvan(VeriBankasi.unvanlar.get(i));
            break;
        }
    }
    return doktor;
}

// Boş doktor listesini dolduran metod.
public static void firstList () {
    for (String w : VeriBankasi.unvanlar) {
        doktorList.add(doktorBul(w));
    }
}

}


