package hospital; // hospital paketi altında bu sınıf yer alıyor.

public class Doktor { // Doktor sınıfı başlangıcı

    // Doktor sınıfı için özellikler (fields) tanımlanıyor.
    private String isim; // Doktorun ismini tutan özellik
    private String soyisim; // Doktorun soyismini tutan özellik
    private String unvan; // Doktorun unvanını tutan özellik

    // Parametresiz kurucu metod
    public Doktor() {
    }

    // Parametre alan kurucu metod
    public Doktor(String isim, String soyisim, String unvan) {
        // Parametreler kullanılarak Doktor özellikleri atanıyor.
        this.isim = isim;
        this.soyisim = soyisim;
        this.unvan = unvan;
    }

    // İsim özelliğinin getter metodu
    public String getIsim() {
        return isim;
    }

    // İsim özelliğinin setter metodu
    public void setIsim(String isim) {
        this.isim = isim;
    }

    // Soyisim özelliğinin getter metodu
    public String getSoyisim() {
        return soyisim;
    }

    // Soyisim özelliğinin setter metodu
    public void setSoyisim(String soyisim) {
        this.soyisim = soyisim;
    }

    // Unvan özelliğinin getter metodu
    public String getUnvan() {
        return unvan;
    }

    // Unvan özelliğinin setter metodu
    public void setUnvan(String unvan) {
        this.unvan = unvan;
    }

    // Doktor nesnesinin string temsilini oluşturan metot
    @Override
    public String toString() {
        return "Doktor{" +
                "isim='" + isim + '\'' +
                ", soyisim='" + soyisim + '\'' +
                ", unvan='" + unvan + '\'' +
                '}';
    }
}
